
print("JWT Verification Message")

print(context.getVariable("request.header.jwt-token"));
print("token verified");