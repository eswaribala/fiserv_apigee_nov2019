 print("hello");

print(context.getVariable("jwt-token"));

context.setVariable("request.header.jwt-token",context.getVariable("jwt-token"));